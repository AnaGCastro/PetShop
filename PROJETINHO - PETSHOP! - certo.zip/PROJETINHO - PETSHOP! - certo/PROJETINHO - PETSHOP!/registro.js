
var url = "http://localhost:3306/";

window.onload = function(){
    getPET((status, PET) => {
        printPET(pets);
    })
}

function getPET(callback){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', URL + "pet", true);
    xhr.responseType = 'json';

    xhr.onload = function(){
        var status = xhr.status;
        if (status === 200){
            callback(status, xhr.response);
            console.log("Deu certinho" + status);
        } else {
            console.log('Deu erro' + status);
        }
    }
    xhr.send();
}

function printPET(genre) {
    for(var i=0; i < pets.length; i++) {
        document.getElementById('tpets').innerHTML += `
        <tr>
            <td>${pets[i].id}</td>
            <td>${pets[i].name}</td>
        </tr>  
    `;
    }
}