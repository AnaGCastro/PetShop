function cadastro(){
    window.open("cadastro.html" , "_self")
    }

function registro(){
    window.open("registro.html" , "_self")
    }

function grafico(){
    window.open("grafico.html" , "_self")
    }